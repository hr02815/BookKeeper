﻿namespace project
{
}
namespace project
{


    public partial class DBprojectDataSet
    {
    }
}
namespace project {
    
    
    public partial class DBprojectDataSet {
    }
}
